package model;

import java.awt.Color;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.event.MouseInputListener;

public class AzioniBottoniNumero implements MouseInputListener {
	
	private int n;
	private Fanculo scelta;
	private JLabel bottone;
	private Border in;
	private Border out;
	private Border bordoPuntate = BorderFactory.createLineBorder(Color.BLACK);

	public AzioniBottoniNumero(int n, Fanculo scelta, JLabel bottone) {
		this.n = n;
		this.scelta = scelta;
		this.bottone = bottone;
		in = BorderFactory.createLineBorder(new Color(0x970ba1),7);
		out = BorderFactory.createLineBorder(Color.WHITE);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		scelta.setA(n);
		System.out.println(scelta);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		bottone.setBorder(in);
	}

	@Override
	public void mouseExited(MouseEvent e) {
		if(n<38)
			bottone.setBorder(out);
		else
			bottone.setBorder(bordoPuntate);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
