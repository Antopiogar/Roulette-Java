package model;

public class Fanculo {
	private int a;

	public Fanculo(int a) {
		this.a = a;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	@Override
	public String toString() {
		return "a= " +a;
	}

	
}
