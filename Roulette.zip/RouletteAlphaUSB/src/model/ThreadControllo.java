package model;

import javax.swing.JOptionPane;

public class ThreadControllo implements Runnable {
	private Casella cVincente;
	private Fanculo f;
	private double valPuntato;
	private int [] primaFila= {
			3,6,9,12,15,18,21,24,27,30,33,36
	};
	private int [] secondaFila= {
			2,5,8,11,14,17,20,23,26,29,32,35
	};
	private int [] terzaFila= {
			1,4,7,10,13,16,19,22,25,28,31,34
	};
	
	public ThreadControllo(Casella cVincente, Fanculo f, double valPuntato) {
		this.cVincente = cVincente;
		this.f = f;
		this.valPuntato = valPuntato;
	}
	private boolean isInPrimaFila() {
		for (int n:primaFila)
			if(n==cVincente.getNumero())
				return true;
		return false;
	}
	private boolean isInSecondaFila() {
		for (int n:secondaFila)
			if(n==cVincente.getNumero())
				return true;
		return false;
	}
	private boolean isInTerzaFila() {
		for (int n:terzaFila)
			if(n==cVincente.getNumero())
				return true;
		return false;
	}
	private boolean isRosso() {
		return cVincente.getColore().equals("rosso") ? true : false;
	}
	private boolean isNero() {
		return cVincente.getColore().equals("nero") ? true : false;
	}
	private boolean isNumber() {
		return f.getA()<38 ?true : false;
	}
	@Override
	public void run() {
		System.out.println("THREAD CONTROLLO INIZIATO");
		for(int i =15;i>1;i--) {
			try {
				System.out.println("Risultato tra "+ i +" secondi");
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		}
		System.out.println("Risultato tra 1 secondo");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
		if(isNumber()) {
			if(f.getA() == cVincente.getNumero()) {
				JOptionPane.showMessageDialog(null, "HAI VINTO "+valPuntato*36);
				System.exit(0);
			}
			else {
				JOptionPane.showMessageDialog(null, "HAI PERSO");
				System.exit(0);
			}
		}else {
			switch (f.getA()) {
				case 40:{
					if(isInPrimaFila()) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+valPuntato*3);
						System.exit(0);
					}
					else {
						JOptionPane.showMessageDialog(null, "HAI PERSO");
						System.exit(0);
					}
					System.exit(0);
				}	
				case 41:{
					if(isInSecondaFila()) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3);
						System.exit(0);
					}
					else {
						JOptionPane.showMessageDialog(null, "HAI PERSO");
						System.exit(0);
					}
					System.exit(0);
				}
				case 42:{
					if(isInTerzaFila()) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3);
						System.exit(0);
					}
					else {
						JOptionPane.showMessageDialog(null, "HAI PERSO");
					}
					System.exit(0);
				}
				case 43:{
					if(cVincente.getNumero()>=1 && cVincente.getNumero()<=12) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 44:{
					if(cVincente.getNumero()>=13 && cVincente.getNumero()<=24) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 45:{
					if(cVincente.getNumero()>=25 && cVincente.getNumero()<=36) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 46:{
					if(cVincente.getNumero()>=1 && cVincente.getNumero()<=18) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*2 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 47:{
					if(cVincente.getNumero()%2==1) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*2 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 48:{
					if(isRosso()) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*2 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 49:{
					if(isNero()) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*2 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 50:{
					if(cVincente.getNumero()%2==0) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*2 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
				case 51:{
					if(cVincente.getNumero()>=19 && cVincente.getNumero()<=36) {
						JOptionPane.showMessageDialog(null, "Hai vinto"+ valPuntato*3 ,"RISULTATO",0);
						System.exit(0);
					}else {
						JOptionPane.showMessageDialog(null, "Hai perso","RISULTATO",0);
						System.exit(0);
					}
				}
			}
		}
	}

}
