package app;

import java.net.MalformedURLException;

import javax.swing.JPanel;

import model.Casella;
import model.Menu;

public class App {

	public static void main(String[] args) throws MalformedURLException {

		Casella c = new Casella();
		JPanel panel = new JPanel();
		Menu m = new Menu(c, panel);
		m.visualizza();
		}
}
